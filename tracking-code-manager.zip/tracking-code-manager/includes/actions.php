<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
